using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml;
using Windows.System;
using Windows.UI.Core;
using Windows.Gaming.Input;
using System;

namespace HorizonXboxStarter
{
    public sealed partial class MainPage : Page
    {
        private DispatcherTimer timer;
        public MainPage()
        {
            InitializeComponent();
            Loaded += OnLoaded;
            Window.Current.CoreWindow.KeyDown += OnKeyDown;
            PointerMoved += OnPointerMoved;
            timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
            timer.Tick += PollController;
            timer.Start();
        }
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Focus(FocusState.Programmatic);
            StatusText.Text = "App launched. Input test is active.";
        }
        private void OnKeyDown(CoreWindow sender, KeyEventArgs args)
        {
            InputText.Text = "Keyboard: " + args.VirtualKey.ToString();
        }
        private void OnPointerMoved(object sender, PointerRoutedEventArgs e)
        {
            var p = e.GetCurrentPoint(this).Position;
            InputText.Text = "Mouse: X " + ((int)p.X) + " / Y " + ((int)p.Y);
        }
        private void PollController(object sender, object e)
        {
            var pads = Gamepad.Gamepads;
            if (pads.Count == 0) return;
            var reading = pads[0].GetCurrentReading();
            InputText.Text = "Controller: buttons=" + reading.Buttons.ToString()
                + "  leftX=" + reading.LeftThumbstickX.ToString("0.00")
                + "  leftY=" + reading.LeftThumbstickY.ToString("0.00");
        }
    }
}
