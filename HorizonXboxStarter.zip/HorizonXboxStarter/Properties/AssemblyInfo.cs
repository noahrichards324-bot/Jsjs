using System.Reflection;
using System.Runtime.InteropServices;
using Windows.UI.Xaml;

[assembly: AssemblyTitle("Horizon Xbox Starter")]
[assembly: AssemblyDescription("UWP app shell and input test starter")]
[assembly: AssemblyCompany("Horizon Xbox Starter")]
[assembly: AssemblyProduct("Horizon Xbox Starter")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
