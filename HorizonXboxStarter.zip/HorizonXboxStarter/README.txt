HORIZON XBOX STARTER — MILESTONE 1
=================================

WHAT THIS IS
------------
A C# Universal Windows Platform (UWP) starter app intended as an initial Xbox
Series X|S Developer Mode test. It displays keyboard events, mouse pointer
activity, and live Xbox Gamepad state.

WHAT THIS IS NOT
----------------
This is NOT Horizon, Minecraft, or a playable game. It does not contain the
Horizon Rust engine, Minecraft assets, account sign-in, networking, or game
rendering. It is only the first app-shell/input milestone. The real Horizon
port would require substantial renderer, platform, packaging, and device work.

TARGET
------
- UWP / Windows 10 SDK target 10.0.22621.0
- Minimum target 10.0.18362.0
- x64 package architecture, intended for Xbox Series X|S Dev Mode

BUILD REQUIREMENTS
------------------
A Windows 10/11 PC is required to compile and package this project. Install
Visual Studio 2022 with the Universal Windows Platform development workload,
a Windows 10/11 SDK, and the .NET Native tooling. Open HorizonXboxStarter.sln,
select Release | x64, then create an app package for sideloading.

A GitHub Actions workflow is included in .github/workflows/build-uwp.yml. It
attempts to build and sign a test package on a hosted Windows runner after the
project is pushed to a GitHub repository. The resulting test certificate must
be trusted by the Xbox before the package can be installed. Keep the .cer file
with the matching .appx; do not share the private .pfx signing key.

XBOX INSTALLATION
-----------------
After a signed package is successfully built, use Xbox Device Portal in the
same local network to install the .appx package. The exact certificate-trust
step can vary with Xbox OS / Dev Home versions. This source archive itself
cannot be installed directly on the Xbox.

INPUT TEST
----------
- Connect a USB or Xbox Wireless Controller and check the controller panel.
- Use a USB keyboard and check the keyboard panel.
- Use a USB mouse and check the mouse panel.

NEXT MILESTONE
--------------
Once the shell is running on the console, test input and platform APIs, then
start evaluating what changes are needed to host Horizon's Rust/wgpu renderer.
Do not assume the desktop or Android Horizon binaries can be loaded into UWP.
