# Horizon Xbox Starter (prototype)

This is a **starter UWP shell**, not Horizon Minecraft and not a finished Xbox port.

It is intended to test whether a basic UWP app can be built in GitHub Actions and deployed in Xbox Developer Mode. It does not contain Horizon's Rust engine, Minecraft assets, account sign-in, networking, or game rendering.

## Build from a phone

1. Create a new **public or private** GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository.
3. Open the **Actions** tab and enable workflows if prompted.
4. Run the workflow named **Build UWP starter**.
5. Download the `HorizonXboxStarter-UWP` artifact from the completed workflow run.

The workflow uses a Windows GitHub-hosted runner with Visual Studio/MSBuild. It may need adjustments if the runner's installed UWP SDK changes.

## Xbox deployment

The generated package is a development prototype. Install it only through Xbox Device Portal while the console is in Developer Mode. A successful PC-side build does not guarantee Xbox compatibility; the app must still be tested on the console.

## Input

The app displays key and pointer events and reports Xbox controller button/axis input using XInput where available. Xbox controller input support in this shell is experimental; keyboard/mouse and controller behavior must be verified on the actual console.
